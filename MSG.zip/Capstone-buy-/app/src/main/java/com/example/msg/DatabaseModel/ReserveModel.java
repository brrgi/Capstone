package com.example.msg.DatabaseModel;

public class ReserveModel {
    public String reservation_id = null;
    public String user_id = null;
    public String category = null;
    public String keyword = null;
}
