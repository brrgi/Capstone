package com.example.msg.Domain;

import com.google.firebase.firestore.FirebaseFirestore;

public class SaleApi {
    public static FirebaseFirestore db = FirebaseFirestore.getInstance();

    public static void getSales() {

    }
}
