package com.example.msg.DatabaseModel;

public class SaleModel {
    public String saleId = null;
    public String userId = null;
    public String productId = null;
    public String salesDate = null;

}
