package com.example.msg.DatabaseModel;

public class UserModel {
    public String userId = null;
    public String userName = null;
    public int age = -1;
    public boolean isMale = false;
    public String userAddress = null;
    public String userPhone = null;
    public String email = null;
    public int mileage = -1;
    public int banCount = -1;
    public int userGrade = -1;
}
