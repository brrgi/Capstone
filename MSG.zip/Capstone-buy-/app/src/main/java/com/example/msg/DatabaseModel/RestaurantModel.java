package com.example.msg.DatabaseModel;

public class RestaurantModel {
    public String resId = null;
    public String resName = null;
    public String resAddress = null;
    public String resImageURL = null;
    public String resDescription = null;
    public String resPickupTime = null;
}
