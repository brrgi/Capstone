package com.example.msg.DatabaseModel;

public class SubscriptionModel {
    public String subsId = null;
    public String userId = null;
    public String resId = null;
}
