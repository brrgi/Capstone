package com.example.msg.Domain;

public class RestaurantProductApi {
}
